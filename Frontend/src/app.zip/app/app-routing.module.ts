import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppointmentSettingComponent } from './appointment-setting/appointment-setting.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { AuthconsultancyGuard } from './authconsultancy.guard';
import { ConsultancyComponent } from './consultancy/consultancy.component';
import { ContentComponent } from './content/content.component';
import { Content2Component } from './content2/content2.component';
import { ContentlinkComponent } from './contentlink/contentlink.component';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { EyecontactComponent } from './eyecontact/eyecontact.component';
import { HistoryComponent } from './history/history.component';
import { PasteventComponent } from './pastevent/pastevent.component';
import { PatentdetailComponent } from './patentdetail/patentdetail.component';
import { PaymentComponent } from './payment/payment.component';
import { PricingComponent } from './pricing/pricing.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { SiginComponent } from './sigin/sigin.component';
import { SignupComponent } from './signup/signup.component';
import { TodayeventComponent } from './todayevent/todayevent.component';
import { TryglassComponent } from './tryglass/tryglass.component';
import { UauthGuard } from './uauth.guard';
import { UpcomingeventComponent } from './upcomingevent/upcomingevent.component';
import { ViewComponent } from './view/view.component';


const routes: Routes = [
 
  {path:'signup',component:SignupComponent},
  {path:'',component:SiginComponent},
  // {path:'Pdashboard',component:ContentComponent,canActivate:[UauthGuard],children:[
  //   {path:'',component:ContentlinkComponent},
  //   {path:'eyeform',component:EyecontactComponent},
  //   {path:'view',component:ViewComponent},
  //   {path:'app',component:AppointmentComponent},
  //   {path:'try',component:TryglassComponent},
  //   {path:'consultancy',canActivate:[AuthconsultancyGuard],component:ConsultancyComponent},
  //   {path:'payment',component:PaymentComponent},
  //   {path:'editprofile',component:EditprofileComponent},
  //   {path:'history',component:HistoryComponent},
  //   {path:'plan',component:PricingComponent}
    
  // ]},
  {path:'Ddashboard',component:Content2Component,canActivate:[UauthGuard],children:[
    {path:'',component:SidebarComponent,children:[
      {path:'set',component:AppointmentSettingComponent},
      {path:'',component:UpcomingeventComponent},
      {path:'todayevent',component:TodayeventComponent},
      {path:'pastevent',component:PasteventComponent},
      {path:'patientdetail',component:PatentdetailComponent},
      {path:'editprofile',component:EditprofileComponent}
    ]},
   
  ]},
 
  { path: 'doctor', loadChildren: () => import('./doctor/doctor.module').then(m => m.DoctorModule) },
 
  { path: 'patient-module', loadChildren: () => import('./patient/patient.module').then(m => m.PatientModule) },
 
  { path: 'navbar-module', loadChildren: () => import('./navbar/navbar.module').then(m => m.NavbarModule) },
 
  { path: 'edit', loadChildren: () => import('./edit/edit.module').then(m => m.EditModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
