import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EyecontactComponent } from './eyecontact/eyecontact.component';
import {InputTextModule} from 'primeng/inputtext';
import {CalendarModule} from 'primeng/calendar';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {DropdownModule} from 'primeng/dropdown';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {InputSwitchModule} from 'primeng/inputswitch';
import {CheckboxModule} from 'primeng/checkbox';
import {ButtonModule} from 'primeng/button';
import {HttpClientModule} from '@angular/common/http';
import { SignupComponent } from './signup/signup.component'; 
import {SelectButtonModule} from 'primeng/selectbutton';
import { SiginComponent } from './sigin/sigin.component';
import {PasswordModule} from 'primeng/password';
import {DataViewModule} from 'primeng/dataview';
import {FileUploadModule} from 'primeng/fileupload';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ContentlinkComponent } from './contentlink/contentlink.component';
import { ContentComponent } from './content/content.component';
import {TabViewModule} from 'primeng/tabview';
import {PanelModule} from 'primeng/panel';
import { ViewComponent } from './view/view.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
import interactionPlugin from '@fullcalendar/interaction';
import { ScheduleModule } from '@syncfusion/ej2-angular-schedule';
import { TryglassComponent } from './tryglass/tryglass.component';
import { Content2Component } from './content2/content2.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import {ColorPickerModule} from 'primeng/colorpicker';
import {SidebarModule} from 'primeng/sidebar';
import {BasePanelMenuItem, PanelMenuModule} from 'primeng/panelmenu';
import {MenuItem} from 'primeng/api';
import { AppointmentSettingComponent } from './appointment-setting/appointment-setting.component';
import {MultiSelectModule} from 'primeng/multiselect';
import {FieldsetModule} from 'primeng/fieldset';
import { UpcomingeventComponent } from './upcomingevent/upcomingevent.component';
import { TodayeventComponent } from './todayevent/todayevent.component';
import { PasteventComponent } from './pastevent/pastevent.component';
import { PatentdetailComponent } from './patentdetail/patentdetail.component';
import { DatechangePipe } from './datechange.pipe';
import { TimechangePipe } from './timechange.pipe';
import {TableModule} from 'primeng/table';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { HistoryComponent } from './history/history.component';
import { ConsultancyComponent } from './consultancy/consultancy.component';
import {ToolbarModule} from 'primeng/toolbar';
import {InputNumberModule} from 'primeng/inputnumber';


// Import your library
import { NgxStripeModule } from 'ngx-stripe';
import {StripeCheckoutModule} from 'ng-stripe-checkout';
import { PaymentComponent } from './payment/payment.component';
import { PricingComponent } from './pricing/pricing.component';

FullCalendarModule.registerPlugins([ // register FullCalendar plugins
  dayGridPlugin,
  timeGridPlugin,
  listPlugin,
  interactionPlugin
]);

@NgModule({
  declarations: [
    AppComponent,
    EyecontactComponent,
    SignupComponent,
    SiginComponent,
    DashboardComponent,
    ContentlinkComponent,
    ContentComponent,
    ViewComponent,
    AppointmentComponent,
    TryglassComponent,
    Content2Component,
    SidebarComponent,
    AppointmentSettingComponent,
    UpcomingeventComponent,
    TodayeventComponent,
    PasteventComponent,
    PatentdetailComponent,
    DatechangePipe,
    TimechangePipe,
    EditprofileComponent,
    HistoryComponent,
    ConsultancyComponent,
    PaymentComponent,
    PricingComponent
  ],
  imports: [
    BrowserModule,
    InputTextModule,
    CalendarModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    DropdownModule,
    InputTextareaModule,
    PasswordModule,
    DataViewModule,
    FileUploadModule,
    ColorPickerModule,
    ToolbarModule,
    TabViewModule,
    PanelModule,
    FullCalendarModule,
    SelectButtonModule,
    FieldsetModule,
    InputSwitchModule,
    CheckboxModule,
    HttpClientModule,
    ButtonModule,
    TableModule,
    InputNumberModule,
    SidebarModule,
    PanelMenuModule,
    MultiSelectModule,
    ScheduleModule,
    AppRoutingModule
  ],
  exports: [
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
