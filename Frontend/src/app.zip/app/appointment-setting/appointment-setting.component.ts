import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-appointment-setting',
  templateUrl: './appointment-setting.component.html',
  styleUrls: ['./appointment-setting.component.css']
})
export class AppointmentSettingComponent implements OnInit {
 days=[];
 selectedday:[
   {name:'',week:''}
 ];
 appdate;
 apptime;
 starttime:Date;
 endtime:Date;
setdate=[];
setday=[];
doctorinfo;
blockday;
blockdate;
newstarttime;
newendtime;
  constructor(private ds:DataService) {
    this.days = [
      {name: 'Sunday', week: 0},
      {name: 'Monday', week:1},
      {name: 'Tuesday', week:2},
      {name: 'Wednesday', week:3},
      {name: 'Thursday', week: 4},
      {name: 'Friday',week: 5},
      {name: 'Saturday',week:6}
     ];

   }

  ngOnInit(): void {
    this.ds.getdoctor({id:localStorage.getItem('id')}).subscribe((response)=>{
      if(response.status=="ok")
      {
          this.doctorinfo=response.data[0];
          this.newstarttime=this.doctorinfo.starttime;
          this.newendtime=this.doctorinfo.endtime;
          this.blockday=this.doctorinfo.blockday;
          this.blockdate=this.doctorinfo.blockdate;
      }else{
          alert(response.data);
      }
  })
  }

  submit(){
    // this.starttime.setUTCSeconds(0);
    // alert(this.starttime.toLocaleTimeString())
    // return true
    let tempstarttime,tempendtime,tempcheckstarttime,tempcheckendtime;
    if(Boolean(this.appdate)){
      for(let i=0;i<this.appdate.length;i++){
        let temp=new Date(this.appdate[i].toISOString().split('T')[0]);
        temp.setDate(temp.getDate()+1)
        this.setdate.push(temp.toISOString().split('T')[0])
      }
    }else if(Boolean(this.blockdate)){
      this.setdate=this.blockdate;
    }
   
   if(Boolean(this.selectedday)){
    for(let i=0;i<this.selectedday.length;i++){
      let day=this.selectedday[i].week;
      this.setday.push(this.selectedday[i].week);
    }
    
   }else{
    this.setday=this.blockday;
   }
   
   if(Boolean(this.starttime)){
   
    tempstarttime=this.starttime.getTime();
    this.starttime.setUTCSeconds(0);
    tempcheckstarttime=this.starttime.toLocaleTimeString('en-GB',{hour: '2-digit', minute:'2-digit'})
   }
   else{
     alert("Choose Appointment Start Time");
     this.setdate=[];
     this.setday=[];
     return true;
   }
    if(Boolean(this.endtime)){
        tempendtime=this.endtime.getTime();
       
    }
    else{
      alert("Choose Appointment End Time");
      this.setdate=[];
      this.setday=[];
      return true;
    }
    if(Boolean()==false){

    }

  
    //api
    this.ds.appointmentsetting({id:localStorage.getItem('id'),blockdate:this.setdate,blockday:this.setday,starttime:tempstarttime,endtime:tempendtime,CheckStartTime:tempcheckstarttime}).subscribe((response)=>{
      if(response.status=="ok"){
        alert(response.data);
        this.starttime;
        this.setdate=[];
        this.setday=[];
        this.endtime;
        this.selectedday;
      }
      else{
        alert(response.data);
      }
    })


  }


}
