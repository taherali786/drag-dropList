import { TestBed } from '@angular/core/testing';

import { AuthconsultancyGuard } from './authconsultancy.guard';

describe('AuthconsultancyGuard', () => {
  let guard: AuthconsultancyGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(AuthconsultancyGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
