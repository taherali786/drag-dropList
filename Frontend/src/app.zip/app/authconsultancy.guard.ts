import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class AuthconsultancyGuard implements CanActivate {
  constructor(private ds:DataService,private router:Router){}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      return new Promise((res, rej) => {
        this.ds.OnlineConsultancy({id:localStorage.getItem('id')}).subscribe(( (response) => {
          if (response.status == true) {
            res(true);
          }
          else {
            this.router.navigate['/']
            res(false)
          }
        }))
      })
  }
  
}
