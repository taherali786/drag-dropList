import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentlinkComponent } from './contentlink.component';

describe('ContentlinkComponent', () => {
  let component: ContentlinkComponent;
  let fixture: ComponentFixture<ContentlinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContentlinkComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentlinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
