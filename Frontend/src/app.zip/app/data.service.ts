import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

baseURL='http://localhost:3000'; 
//  baseURL='http://18.223.136.68:7000';
  constructor(private http:HttpClient) {
   }
   getadd(d):any
   {
    return this.http.post(this.baseURL+'/get-add',d);
   }

   setclient(d):any
   {
    return this.http.post(this.baseURL+'/set-client',d);
   }

   signup(d):any
   {
    return this.http.post(this.baseURL+'/signup',d);
   }
   signin(d):any
   {
    return this.http.post(this.baseURL+'/signin',d);
   }

   appointmentsetting(d):any{
    return this.http.post(this.baseURL+'/appointment-setting',d);
   }

   getdoctorinfo(d):any{
    return this.http.post(this.baseURL+'/get-doctor-role',d);
   }

   getdoctor(d):any{
     //alert(JSON.stringify(d));
    return this.http.post(this.baseURL+'/get-doctor',d);
   }

   setappointmentrequest(d):any{
    return this.http.post(this.baseURL+'/setappointmentrequest',d);
   }

   getupcomingevent(d):any{
   return this.http.post(this.baseURL+'/upcomingevent',d);
  }
  getpastevent(d):any{
    return this.http.post(this.baseURL+'/pastevent',d);
   }

   gettodayevent(d):any{
    return this.http.post(this.baseURL+'/todayevent',d);
   }

   getevent(d):any{
    return this.http.post(this.baseURL+'/event',d);
   }

   rejectreq(d):any{
    return this.http.post(this.baseURL+'/reject-req',d);
   }

   acceptreq(d):any{
    return this.http.post(this.baseURL+'/accept-req',d);
   }

   updateprofile(d):any{
    return this.http.post(this.baseURL+'/update-profile',d);
   }

   getspecificdoctor(d):any{
    return this.http.post(this.baseURL+'/specific-doctor',d);
   }

   changepassword(d):any
   {
    return this.http.post(this.baseURL+'/change-password',d);
   }

   getclient(d):any
   {
    return this.http.post(this.baseURL+'/get-client',d);
   }

   bookGlass(d):any{
    return this.http.post(this.baseURL+'/book-glass',d);
   }

   getBookGlassDetail(d):any{
     return this.http.post(this.baseURL+'/get-booked-glass',d);
   }

   UpdateUserPic(d):any{
     return this.http.post(this.baseURL+'/update-user-pic',d);
   }

   Payment(d):any{
    return this.http.post(this.baseURL+'/Get-Payment',d);
   }

   OnlineConsultancy(d):any{
    return this.http.post(this.baseURL+'/Auth-Online-Consultancy',d);
   }

}
