import { DatechangePipe } from './datechange.pipe';

describe('DatechangePipe', () => {
  it('create an instance', () => {
    const pipe = new DatechangePipe();
    expect(pipe).toBeTruthy();
  });
});
