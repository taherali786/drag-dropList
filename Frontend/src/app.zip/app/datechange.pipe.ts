import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';

@Pipe({
  name: 'datechange'
})
export class DatechangePipe implements PipeTransform {

  transform(value: string ): unknown {
    let d= moment(value).format("DD/MM/YYYY");
    return d;
  }

}
