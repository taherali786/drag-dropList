import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppointmentSettingComponent } from './appointment-setting/appointment-setting.component';
import { Content2Component } from './content2/content2.component';

import { DoctorComponent } from './doctor.component';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { PasteventComponent } from './pastevent/pastevent.component';
import { PatentdetailComponent } from './patentdetail/patentdetail.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { TodayeventComponent } from './todayevent/todayevent.component';
import { UauthGuard } from './uauth.guard';
import { UpcomingeventComponent } from './upcomingevent/upcomingevent.component';

const routes: Routes = [
  // { path: '', component: DoctorComponent },
{ path: 'navbar-module', loadChildren: () => import('../navbar/navbar.module').then(m => m.NavbarModule) },

{path:'',component:DoctorComponent,canActivate:[UauthGuard],children:[
  {path:'',component:SidebarComponent,children:[
    {path:'set',component:AppointmentSettingComponent},
    {path:'',component:UpcomingeventComponent},
    {path:'todayevent',component:TodayeventComponent},
    {path:'pastevent',component:PasteventComponent},
    {path:'patientdetail',component:PatentdetailComponent},
    { path: 'edit', loadChildren: () => import('../edit/edit.module').then(m => m.EditModule) },
    {path:'editprof',component:EditprofileComponent}
  ]},
 
]}


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DoctorRoutingModule { }
