import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

import { DoctorRoutingModule } from './doctor-routing.module';
 import { DoctorComponent } from './doctor.component';
import { Content2Component } from './content2/content2.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { AppointmentSettingComponent } from './appointment-setting/appointment-setting.component';
import { UpcomingeventComponent } from './upcomingevent/upcomingevent.component';
import { TodayeventComponent } from './todayevent/todayevent.component';
import { PasteventComponent } from './pastevent/pastevent.component';
import { PatentdetailComponent } from './patentdetail/patentdetail.component';
import {HttpClientModule} from '@angular/common/http';


// PrimeNg Modules
 import {MultiSelectModule} from 'primeng/multiselect';
import {BasePanelMenuItem, PanelMenuModule} from 'primeng/panelmenu';
import {PanelModule} from 'primeng/panel';
import {ColorPickerModule} from 'primeng/colorpicker';
import {SidebarModule} from 'primeng/sidebar';
import {PasswordModule} from 'primeng/password';
import {FileUploadModule} from 'primeng/fileupload';
import {DropdownModule} from 'primeng/dropdown';
import {ButtonModule} from 'primeng/button';
import {InputTextModule} from 'primeng/inputtext';
import {CalendarModule} from 'primeng/calendar';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {TableModule} from 'primeng/table';
 import { NavbarModule } from '../navbar/navbar.module';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { DatechangePipe } from './datechange.pipe';
import { TimechangePipe } from './timechange.pipe';

@NgModule({
  declarations: [
    DoctorComponent,
    Content2Component,
    SidebarComponent,
    AppointmentSettingComponent,
    UpcomingeventComponent,
    TodayeventComponent,
    PasteventComponent,
    PatentdetailComponent,
    DatechangePipe,
    TimechangePipe,
  ],
  imports: [
    CommonModule,
    DoctorRoutingModule,
    InputTextModule,
    CalendarModule,
    FormsModule,
    ReactiveFormsModule,
    DropdownModule,
    PasswordModule,
    FileUploadModule,
    ColorPickerModule,
    PanelModule,
    HttpClientModule,
    ButtonModule,
    TableModule,
    SidebarModule,
    PanelMenuModule,
     MultiSelectModule,
    NavbarModule
    
  ]
})
export class DoctorModule { }
