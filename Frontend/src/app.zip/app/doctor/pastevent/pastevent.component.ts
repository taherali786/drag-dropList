import { Component, OnInit } from '@angular/core';
import { Data } from '@angular/router';
import { DataService } from '../../data.service';

@Component({
  selector: 'app-pastevent',
  templateUrl: './pastevent.component.html',
  styleUrls: ['./pastevent.component.css']
})
export class PasteventComponent implements OnInit {

event;
accept=true;
  constructor(private ds:DataService) { }

  ngOnInit(): void {
      this.ds.getpastevent({id:localStorage.getItem('id')}).subscribe(async (response)=>{
        if(response.status=="ok"){
            this.event=await response.data;
        }else{

        }
      })
  }

}
