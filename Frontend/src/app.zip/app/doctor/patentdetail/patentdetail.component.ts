import { Component, OnInit } from '@angular/core';
import { DataService } from '../../data.service';
import { trigger,state,style,transition,animate } from '@angular/animations';

@Component({
  selector: 'app-patentdetail',
  templateUrl: './patentdetail.component.html',
  styleUrls: ['./patentdetail.component.scss'],
  animations: [
    trigger('rowExpansionTrigger', [
        state('void', style({
            transform: 'translateX(-10%)',
            opacity: 0
        })),
        state('active', style({
            transform: 'translateX(0)',
            opacity: 1
        })),
        transition('* <=> *', animate('400ms cubic-bezier(0.86, 0, 0.07, 1)'))
    ])
]
     
})
export class PatentdetailComponent implements OnInit {
  cols: any[];
  event;
  accept=true;
  dname=localStorage.getItem('name');
  dmail=localStorage.getItem('email');
  fee=localStorage.getItem('fee');
  location=localStorage.getItem('location');
    constructor(private ds:DataService) { 
      this.cols = [
        { field: '', header: '' },
        { field: 'Doctor Name', header: 'Doctor Name' },
        { field: 'Doctor Mail ID', header: 'Doctor Mail ID' },
        { field: 'Location', header: 'Location' },
        { field: 'Fee', header: 'fee' }
    ];
    }
  
    ngOnInit(): void {
        this.ds.getevent({id:localStorage.getItem('id')}).subscribe((response)=>{
          if(response.status=="ok"){
              this.event=response.data;
          }else{
  
          }
        })
    }
  

}
