import { TimechangePipe } from './timechange.pipe';

describe('TimechangePipe', () => {
  it('create an instance', () => {
    const pipe = new TimechangePipe();
    expect(pipe).toBeTruthy();
  });
});
