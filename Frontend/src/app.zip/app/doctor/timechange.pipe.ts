import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';

@Pipe({
  name: 'timechange'
})
export class TimechangePipe implements PipeTransform {

  transform(value: Date): unknown {
    let d=new Date(value);
    let t=moment(d).format("hh:mm a");
    return t;
  }

}
