import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TodayeventComponent } from './todayevent.component';

describe('TodayeventComponent', () => {
  let component: TodayeventComponent;
  let fixture: ComponentFixture<TodayeventComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TodayeventComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TodayeventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
