import { Component, OnInit } from '@angular/core';
import { DataService } from '../../data.service';
import * as moment from 'moment';


@Component({
  selector: 'app-todayevent',
  templateUrl: './todayevent.component.html',
  styleUrls: ['./todayevent.component.css']
})
export class TodayeventComponent implements OnInit {

event;
accept=true;
  constructor(private ds:DataService) { }

  ngOnInit(): void {
      this.ds.gettodayevent({id:localStorage.getItem('id')}).subscribe((response)=>{
        if(response.status=="ok"){
            this.event=response.data;
        }else{

        }
      })
  }

  rejectrequest(e,n,d,m,r){
    let date= moment(d).format("DD/MM/YYYY");
    let t=new Date(d);
    let time=moment(t).format("hh:mm a");
    this.ds.rejectreq({id:localStorage.getItem('id'),applicationid:e,request:r,name:n,date:date,time:time,dname:localStorage.getItem('name'),mail:m,requested:r}).subscribe((response)=>{
      if(response.status=="ok"){
          alert('Request  '+r);
          this.ds.getupcomingevent({id:localStorage.getItem('id')}).subscribe((response)=>{
            if(response.status=="ok"){
                this.event=response.data;
            }else{
    
            }
          })
      }else{
          alert(response.data);
      }
    })
  }

}
