import { TestBed } from '@angular/core/testing';

import { UauthGuard } from './uauth.guard';

describe('UauthGuard', () => {
  let guard: UauthGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(UauthGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
