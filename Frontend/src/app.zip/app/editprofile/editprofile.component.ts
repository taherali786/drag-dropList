import { Component, OnInit } from '@angular/core';
import { dragStart } from '@syncfusion/ej2-angular-schedule';
import { DataService } from '../data.service';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-editprofile',
  templateUrl: './editprofile.component.html',
  styleUrls: ['./editprofile.component.css']
})
export class EditprofileComponent implements OnInit {
  nameProp=localStorage.getItem('name');
  emailProp=localStorage.getItem('email');
  locationProp=localStorage.getItem('location');
  specialityProp=localStorage.getItem('speciality');
  feeProp=localStorage.getItem('fee');
  ifrole=localStorage.getItem('role');
  passwordProp;
  confpasswordProp;
  secretkey:string='ch@kkiwala199953';
  constructor(private ds:DataService) { }

  ngOnInit(): void {
  }

  Profilechange(){
          this.ds.updateprofile({id:localStorage.getItem('id'),name:this.nameProp,mail:this.emailProp,location:this.locationProp,speciality:this.specialityProp,fee:this.feeProp}).subscribe((response)=>{
                if(response.status=='ok'){
                    alert(response.data);
                    this.ds.getspecificdoctor({id:localStorage.getItem('id')}).subscribe((response)=>{
                      if(response.status=='ok'){
                        if(response.data[0].role=="Doctor"){
                            this.nameProp=response.data[0].name;
                            this.emailProp=response.data[0].email;
                            this.locationProp=response.data[0].location;
                            this.specialityProp=response.data[0].speciality;
                            this.feeProp=response.data[0].fee;
                           localStorage.setItem("id",response.data[0]._id);
                           localStorage.setItem("name",response.data[0].name);
                           localStorage.setItem("email",response.data[0].email);
                           localStorage.setItem("role",response.data[0].role);
                           localStorage.setItem("location",response.data[0].location);
                           localStorage.setItem('speciality',response.data[0].speciality);
                           localStorage.setItem('fee',response.data[0].fee);  
                         }else{
                            this.nameProp=response.data[0].name;
                            this.emailProp=response.data[0].email;
                            this.locationProp=response.data[0].location;
                           localStorage.setItem("id",response.data[0]._id);
                           localStorage.setItem("name",response.data[0].name);
                           localStorage.setItem("email",response.data[0].email);
                           localStorage.setItem("role",response.data[0].role);
                           localStorage.setItem('location',response.data[0].location);
                         }
                      }else{
                          alert(response.data);
                          
                      }
                    })
                }else{

                  alert(response.data);

                }    
          })
    }

  changepass(){
    if(this.confpasswordProp!=this.passwordProp){
      alert('Both Password Are Not Matched');
    }else{
      var hash=CryptoJS.SHA256(this.passwordProp);
      var password=hash.toString(CryptoJS.enc.Hex);
            this.ds.changepassword({id:localStorage.getItem('id'),password:password}).subscribe((response)=>{
                    if(response.status=="ok"){
                          alert(response.data);
                          this.confpasswordProp='';
                          this.passwordProp='';
                    }else{
                      alert(response.data);
                    }
            })
    }
  }

}
