import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EyecontactComponent } from './eyecontact.component';

describe('EyecontactComponent', () => {
  let component: EyecontactComponent;
  let fixture: ComponentFixture<EyecontactComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EyecontactComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EyecontactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
