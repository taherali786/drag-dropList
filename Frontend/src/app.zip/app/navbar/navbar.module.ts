import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

import { NavbarRoutingModule } from './navbar-routing.module';
import { NavbarComponent } from './navbar.component';
import { FormsModule } from '@angular/forms';

// PrimenG Module
import {ButtonModule} from 'primeng/button';
import {PasswordModule} from 'primeng/password';
import {InputTextModule} from 'primeng/inputtext';
import { EditprofileComponent } from './editprofile/editprofile.component';

@NgModule({
  declarations: [NavbarComponent, EditprofileComponent],
  imports: [
    CommonModule,
    NavbarRoutingModule,
    ButtonModule,
    InputTextModule,
    // BrowserModule,
    FormsModule,
    PasswordModule
  ],
  exports:[
    NavbarComponent,
    EditprofileComponent
  ]
})
export class NavbarModule { }
