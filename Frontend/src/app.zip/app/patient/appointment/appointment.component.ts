import { Component,ViewChild,  OnInit, forwardRef  } from '@angular/core';
 import { CalendarOptions, DateSelectArg, EventClickArg, EventApi } from '@fullcalendar/angular';
// import { INITIAL_EVENTS, createEventId } from './event-utils';
import $ from "jquery";
// import { DashboardComponent } from '../dashboard/dashboard.component';
import { ActivatedRoute } from '@angular/router';
import { DataService } from '../../data.service';
import { EventInput } from '@fullcalendar/angular';


@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent implements OnInit {
  
  currentdate=new Date();
  astime;
  estime;
  calendarVisible = true;
  btn=true;
  titleProp;
  locationProp;
  descProp;
  nameProp;
  mailProp;
  alertfirst=false;
  alertsecond=false;
  currentEvents: EventApi[] = [];
  end;
  d=new Date(2021,0,18,15,52,0);
  md=new Date(2021,0,18,19,52,0);
   id;
   doctorinfo;
   starttime;
   endtime;
   blockday=[];
   blockdate=[];
   calendarOptions;
   sdate:Date;
   edate:Date;
   showstarttime;
   showendtime;
    eventGuid = 0;
    stime:Date;
    etime:Date;
   TODAY_STR = new Date().toISOString().replace(/T.*$/, ''); // YYYY-MM-DD of today
   createevent=[];
   INITIAL_EVENTS: EventInput[] ;

  event;
  eventpush:EventInput[]=[];
   createEventId() {
    return String(this.eventGuid++);
  }
  constructor(private route:ActivatedRoute,private ds:DataService) { 
    
  }
 
  ngOnInit(): void {
    this.route.queryParamMap.subscribe((d)=>{
      this.id=d.get("id");
    })

     this.ds.getevent({id:this.id}).subscribe(async (response)=>{
      if(response.status=="ok")
      {
        this.event=response.data[0].event;
        for(let i=0;i<this.event.length;i++)
        {
          if(this.event[i].request=='accept'){

            await  this.eventpush.push(
              {
                id:this.createEventId(),
                title:this.event[i].name,
                start:this.event[i].starttime,
                end:this.event[i].endtime
              }
            )  
         }
         
        }

        }else{
            console.log(response.data);
        }
    }) 

    this.ds.getdoctor({id:this.id}).subscribe(async (response)=>{
      if(response.status=="ok"){ 
            this.doctorinfo=response.data[0];
            this.starttime=this.doctorinfo.starttime;
            this.endtime=this.doctorinfo.endtime;
            this.blockday=this.doctorinfo.blockday;
            this.blockdate=this.doctorinfo.blockdate;
            this.currentdate = new Date(this.starttime);// Milliseconds to date
            this.astime=this.currentdate.toLocaleTimeString('en-GB',{hour: '2-digit', minute:'2-digit'});
            this.currentdate=new Date(this.endtime);
            this.estime=this.currentdate.toLocaleTimeString('en-GB',{hour: '2-digit', minute:'2-digit'});
            this.calendarOptions = {
              titleFormat:{ year: 'numeric', month: 'short' } ,
              headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek timeGridDay,listWeek'
              },
          
              initialView: 'dayGridMonth',
              initialEvents: this.eventpush, // alternatively, use the `events` setting to fetch from a feed
              weekends: true,
              editable: true,
              selectable: true,
              selectMirror: true,
              dayMaxEvents: true,
              dayHeaderFormat:{ weekday: 'long' },
               slotDuration:'00:10:00',
               slotLabelInterval:'00:10:00',
              slotMinTime:this.astime,
              slotMaxTime:this.estime,
              hiddenDays: this.blockday,
              select: this.handleDateSelect.bind(this),
             // eventClick: this.handleEventClick.bind(this),
              eventsSet: this.handleEvents.bind(this)
              /* you can update a remote database when these fire:
              eventAdd:
              eventChange:
              eventRemove:
              */
            };
        }else{
    
        }
      })
  
   
    

  
  }
  handleCalendarToggle() {
    this.calendarVisible = !this.calendarVisible;
  }

  handleWeekendsToggle() {
    const { calendarOptions } = this;
    calendarOptions.weekends = !calendarOptions.weekends;
  }

  handleDateSelect(selectInfo: DateSelectArg) {
    for(let i=0;i<this.blockdate.length;i++)
    {
      if(selectInfo.startStr==this.blockdate[i]){
         return true;
       }
    }
    //selected date
    let checkdate=new Date(selectInfo.startStr);
    checkdate.setUTCHours(0);
    checkdate.setUTCMinutes(0);
    checkdate.setUTCSeconds(0);
    let d1=checkdate.toUTCString();
    let sd1=new Date(d1);
  
    //new date
    let checkdate2=new Date();
    checkdate2.setUTCHours(0);
    checkdate2.setUTCMinutes(0);
    checkdate2.setUTCSeconds(0);
    let d2=checkdate2.toUTCString();
    let sd2=new Date(d2);
    
    if(sd1.getTime()<sd2.getTime())
    {
      return true;
    }
    this.sdate=new Date(selectInfo.startStr);
    let yr=this.sdate.getFullYear();
    let mn=this.sdate.getMonth();
    let dt=this.sdate.getDate();
    this.sdate.setTime(this.starttime);
    this.edate=new Date(selectInfo.startStr);
    this.edate.setTime(this.endtime);
    this.stime=new Date(selectInfo.startStr);
    this.stime.setTime(this.starttime);
    this.stime.setFullYear(yr);
    this.stime.setMonth(mn);
    this.stime.setDate(dt);
    // alert(this.stime);
    this.etime=new Date(selectInfo.startStr);
    this.etime.setTime(this.endtime);
    this.etime.setFullYear(yr);
    this.etime.setMonth(mn);
    this.etime.setDate(dt);
    // alert(this.etime);
    document.getElementById('start').innerText=selectInfo.startStr;
    document.getElementById('end').innerText=selectInfo.startStr;
    document.getElementById('click').click();
  
    // const title = prompt('Please enter a new title for your event');
     var title = 'hello';
     var title2='hii';
     var final=title+'<br>'+title2;
    const calendarApi = selectInfo.view.calendar;

    calendarApi.unselect(); // clear date selection

    
  }

  handleEventClick(clickInfo: EventClickArg) {
    if (confirm(`Are you sure you want to delete the event '${clickInfo.event.title}'`)) {
      clickInfo.event.remove();
    }
  }

  handleEvents(events: EventApi[]) {
    this.currentEvents = events;
  }
  dayClick(date, allDay, jsEvent) {
    var checkDay = new Date($.fullCalendar.formatDate(date, 'yyyy-MM-dd'));

    if (checkDay.getDay() == 6 || checkDay.getDay() == 0) alert('Weekend!');
}

showtime(){
 
  if(this.stime.toLocaleTimeString('en-US',{hour: '2-digit', minute:'2-digit'})<this.sdate.toLocaleTimeString('en-Us',{hour: '2-digit', minute:'2-digit'}) || this.stime.toLocaleTimeString('en-US',{hour: '2-digit', minute:'2-digit'})>this.edate.toLocaleTimeString('en-Us',{hour: '2-digit', minute:'2-digit'}) )
  {
    this.alertfirst=true;
    this.btn=true;
    return true;

  }else {
    this.alertfirst=false;

  }
  if(this.etime.toLocaleTimeString('en-US',{hour: '2-digit', minute:'2-digit'})<this.sdate.toLocaleTimeString('en-Us',{hour: '2-digit', minute:'2-digit'}) || this.etime.toLocaleTimeString('en-US',{hour: '2-digit', minute:'2-digit'})>this.edate.toLocaleTimeString('en-Us',{hour: '2-digit', minute:'2-digit'}) )
  {
    this.alertsecond=true;
    this.btn=true;
    return true;

  }else {
    //console.log("equal");
    this.alertsecond=false;

  }
  //console.log("hello");
 
  this.btn=false;
}

showtimes(){
 
}
submit()
{
  if(Boolean(this.titleProp) && Boolean(this.locationProp) && Boolean(this.stime) && Boolean(this.etime) && Boolean(this.nameProp) && Boolean(this.mailProp))
  {
    // var localtime=new Date(this.stime);
    let Appid=Math.floor(Math.random()*10000000000+1);
    this.createevent.push({Applicationid:Appid,name:this.nameProp,mail:this.mailProp,patientid:localStorage.getItem('id'),title:this.titleProp,location:this.locationProp,description:this.descProp,starttime:this.stime,endtime:this.etime,request:'pending'});
      this.ds.setappointmentrequest({doctorid:this.id,name:this.doctorinfo.name,email:this.doctorinfo.email,location:this.doctorinfo.location,speciality:this.doctorinfo.speciality,fee:this.doctorinfo.fee,request:this.doctorinfo.request,event:this.createevent}).subscribe((response)=>{
        if(response.status=="ok")
        {
            this.createevent=[];
            this.titleProp='';
            this.locationProp='';
            this.descProp='';
            this.stime;
            this.etime;
            this.nameProp='';
            this.mailProp='';
            document.getElementById('close').click();
            document.getElementById('click2').click();
        }else{
            alert(response.data);
        }
      })
  }else{
    alert("Pease Fill All The Field");
  }
}

}
