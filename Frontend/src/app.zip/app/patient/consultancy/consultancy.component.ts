import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
 
//import { StripeService, StripeCardComponent, ElementOptions, ElementsOptions } from "ngx-stripe";

import {loadStripe} from '@stripe/stripe-js';
import { DataService } from '../../data.service';


@Component({
  selector: 'app-consultancy',
  templateUrl: './consultancy.component.html',
  styleUrls: ['./consultancy.component.css']
})
export class ConsultancyComponent implements OnInit {
  
  loadAPI: Promise<any>; 
  //End Of Stripe

  Amount;
  Name;
  Phone;
  constructor(
    private fb: FormBuilder,
    private ds:DataService
    //private stripeService: StripeService
  ) { 
    
  }
  stripe;
  card;
  async ngOnInit() {
    this.loadScript()
  }

  public loadScript() {
    let d=document;
    let s=d.createElement("script");
    s.src="https://client.crisp.chat/l.js";
    s.async=true;
    d.getElementsByTagName("head")[0].appendChild(s);

      
  }




}
