import { Component, OnInit } from '@angular/core';
import { DataService } from '../../data.service';

@Component({
  selector: 'app-contentlink',
  templateUrl: './contentlink.component.html',
  styleUrls: ['./contentlink.component.scss']
})
export class ContentlinkComponent implements OnInit {
  name = localStorage.getItem('name');
  mail = localStorage.getItem('email');
  location = localStorage.getItem('location');
  data;
  imgProp;
  imagePath=localStorage.getItem('image');
  imagepath = 'http://localhost:3000/';
  //imagepath = 'http://18.223.136.68:7000/';
  image;
  constructor(private ds:DataService) { 
    if(localStorage.getItem('image')!='undefined'){
      this.image=this.imagepath+localStorage.getItem('image')
     }else{
       this.image="../assets/images/icon.png";
     }
  }

  ngOnInit(): void {
  }

  async selectimage(ev){
    const formdata =new FormData();
    if(ev.target.files.length>0){
      const file=ev.target.files[0];
      this.data=await file;  
    }
    
    formdata.append('imgfile',this.data);
    formdata.append('id',localStorage.getItem('id'))
    this.ds.UpdateUserPic(formdata).subscribe((response)=>{
      if(response.status=="ok"){
        console.log(response.data[0].image)
          this.imagePath=response.data[0].image;
          localStorage.setItem('image',this.imagePath);
          this.image=this.imagepath+localStorage.getItem('image')
      }else{
        console.log(response.data)
      }
    },(err)=>{console.log(err)})
  }

}
