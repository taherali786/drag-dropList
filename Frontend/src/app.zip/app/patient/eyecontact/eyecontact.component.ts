import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Dropdown } from 'primeng/dropdown';
import { DataService } from '../../data.service';

@Component({
  selector: 'app-eyecontact',
  templateUrl: './eyecontact.component.html',
  styleUrls: ['./eyecontact.component.scss']
})
export class EyecontactComponent implements OnInit {
value3:Date;
cols: any[];
countries=[];
value10;
selectedCountry;
checked2=true;
checked;
leftsphere;
leftcylinder;
leftaxis;
leftprism;
leftpower;
rightsphere;
rightcylinder;
rightaxis;
rightprism;
rightpower;
leftprismdirection;
rightprismdirection;
post;
post1;
post2;
post3;
computertime=[];
screentime=[];
age=[];
agechk;
computerchk;
screenchk;
glass=false;
lens=false;
light=false;
groupedCities=[];
leftaxispost=[];
selectedCity3;
glasseschk;
prismd=[];
pname;
dname;
date:Date;
mail;
product=[
  {color:'#ffd69c',value:'Single Vision Regular Plastic 1.50-1.56',no:1.50}
];
resultcompare=[
  {color:'#ffd69c',value:'Single Vision Regular Plastic 1.50-1.56',no:1.50},
  {color:'#0088ff',value:'Single Vision High Index 1.60 or Polycorbonate',no:1.60},
  {color:'#bf00ff',value:'Single Vision High Index 1.67',no:1.67},
  {color:'#ff009d',value:'Single Vision High Index 1.74 Thinnest Plastic Available',no:1.74}

];
righteyeresultofspherecylinder;
lefteyeresultofspherecylinder;
righteyepowerresult;
lefteyepowerresult;
finalresult;
tempsphere;
tempcylinder;
finalpower;
  constructor(private ds:DataService) {
      this.computertime=[
        {no:'4-6 hr'},
        {no:'6-10 hr'}
      ];
      this.screentime=[
        {no:'4-6 hr'},
        {no:'6-10 hr'}
      ];
      this.age=[
        {no:'0-5'},
        {no:'6-10'},
        {no:'7-15'},
        {no:'16-20'},
        {no:'21-25'},
        {no:'26-30'},
        {no:'31-40'},
        {no:'41-50'},
        {no:'51-65'},
        {no:'66+'}
      ];
      this.prismd=[
        {no:'up'},
        {no:'down'},
        {no:'BI'},
        {no:'BO'}
      ]
      this.groupedCities = [
        {
            label: 'Reading', value: 'reading', 
            items: [
                {label: 'Progressive', value: 'Progressive'},
                {label: 'Office Progressive', value: 'Office Progressive'},
               
            ]
        },
        {
            label: 'Distance', value: 'Distance', 
            items: [
                {label: 'Bifocal', value: 'Bifocal'},
                {label: 'Computer Only', value: 'Computer Only'},
              
            ]
        },
        {
            label: 'None', value: 'None', 
            items: [
                {label: 'None', value: 'None'},
                {label: 'Do Not Know', value: 'Do Not Know'},
            ]
        }
    ];
    for (let i = 1; i < 181; i++) {
      this.leftaxispost.push({no: i});
  }
        this.cols = [
          { field: 'code', header: '' },
          { field: 'name', header: 'Sphere' },
          { field: 'category', header: 'Cylinder' },
          { field: 'quantity', header: 'Axis' },
          { field: 'quantity', header: 'prism' },
          { field: 'quantity', header: '' },
          { field: 'quantity', header: 'Add Power'}
      ];
   }

  ngOnInit(): void {
    this.ds.getadd({fieldname:'add'}).subscribe((response)=>{
      if(response.status=="ok")
      {
        this.post=response.data[0].colorno;
      
      }else{
        alert("data not found");
      }
    })  
    this.ds.getadd({fieldname:'addsphere'}).subscribe((response)=>{
      if(response.status=="ok")
      {
        this.post1=response.data[0].colorno;
      
      }else{
        alert("data not found");
      }
    })  
    this.ds.getadd({fieldname:'addcylinder'}).subscribe((response)=>{
      if(response.status=="ok")
      {
        this.post2=response.data[0].colorno;
      
      }else{
        alert("data not found");
      }
    })  
    this.ds.getadd({fieldname:'addprism'}).subscribe((response)=>{
      if(response.status=="ok")
      {
        this.post3=response.data[0].colorno;
      
      }else{
        alert("data not found");
      }
    })  
  }

  rytsphere(e)
  {
 
    document.getElementById('ryts').style.background=e.value.color;
  }
  rytcylinder(e)
  {
  
    document.getElementById('rytc').style.background=e.value.color;
  }
  rytpower(e)
  {
    
    document.getElementById('rytp').style.background=e.value.color;
  }
  lftsphere(e)
  {
 
    document.getElementById('lfts').style.background=e.value.color;
  }
  lftcylinder(e)
  {
 
    document.getElementById('lftc').style.background=e.value.color;
  }
  lftpower(e)
  {
 
    document.getElementById('lftp').style.background=e.value.color;
  }

  submit()
  {
    if(Boolean(this.pname)==false){
      alert("Please Enter Your Name");
      return true;
    }
    if(Boolean(this.dname)==false){
      alert("Please Enter Doctor Name");
      return true;
    }
    if(Boolean(this.mail)==false)
    {
      alert("Please Enter Your Mail");
      return true;
    }
    if(Boolean(this.date)==false)
    {
      alert("Please Enter Date");
      return true;
    }
   if(Boolean(this.leftaxis)==false){
     alert("Please Fill Left Eye Axis");
     return true;
   }
   if(Boolean(this.leftcylinder)==false){
    alert("Please Fill Left Eye Cylinder");
    return true;
  }
  if(Boolean(this.leftpower)==false){
    alert("Please Fill Left Eye Power");
    return true;
  }
  if(Boolean(this.leftprism)==false){
    alert("Please Fill Left Eye Prism");
    return true;
  }
  if(Boolean(this.leftprismdirection)==false){
    alert("Please Fill Left Eye Prism Direction");
    return true;
  }
  if(Boolean(this.leftsphere)==false){
    alert("Please Fill Left Eye Sphere");
    return true;
  }
  if(Boolean(this.rightaxis)==false){
    alert("Please Fill Right Eye Axis");
    return true;
  }
  if(Boolean(this.rightcylinder)==false){
    alert("Please Fill Right Eye Cylinder");
    return true;
  }
  if(Boolean(this.rightpower)==false){
    alert("Please Fill Right Eye Power");
    return true;
  }
  if(Boolean(this.rightprism)==false){
    alert("Please Fill Right Eye Prism");
    return true;
  }
  if(Boolean(this.rightprismdirection)==false){
    alert("Please Fill Right Eye Prism Direction");
    return true;
  }
  if(Boolean(this.rightsphere)==false){
    alert("Please Fill Right Eye Sphere");
    return true;
  }
   if(Boolean(this.agechk)==false)
   {
     alert("Please Enter Age");
     return true;
   }
   if(Boolean(this.glasseschk)==false)
   {
    alert("Please Enter Glass You Wear");
    return true;
   }
    if(Boolean(this.checked)==false)
    {
      alert("Please Check Term And Conditions");
    }

  // Right EYE Result

  if(Number(this.rightsphere.no)>Number(this.rightcylinder.no))
  {

    this.righteyeresultofspherecylinder=this.resultcompare.find(obj=>{
      return obj.color==this.rightsphere.color
    });
    
    
  }else if(Number(this.rightsphere.no)==Number(this.rightcylinder.no))
  {
      this.tempsphere=this.resultcompare.find(obj=>{
        return obj.color==this.rightsphere.color
      });
      this.tempcylinder=this.resultcompare.find(obj=>{
        return obj.color==this.rightcylinder.color
      });
      if(Number(this.tempsphere.no)>Number(this.tempcylinder.no))
      {
        this.righteyeresultofspherecylinder=this.tempsphere;
      }else{
        this.righteyeresultofspherecylinder=this.tempcylinder;
      }
      
  }
  else{
    this.righteyeresultofspherecylinder=this.resultcompare.find(obj=>{
      return obj.color==this.rightcylinder.color
    });
  }

  // Left EYE Result

  if(Number(this.leftsphere.no)>Number(this.leftcylinder.no))
  {
    this.lefteyeresultofspherecylinder=this.resultcompare.find(obj=>{
      return obj.color==this.leftsphere.color
    });
  }else if(Number(this.leftsphere.no)==Number(this.leftcylinder.no))
  {
      this.tempsphere=this.resultcompare.find(obj=>{
        return obj.color==this.leftsphere.color
      });
      this.tempcylinder=this.resultcompare.find(obj=>{
        return obj.color==this.leftcylinder.color
      });
      if(Number(this.tempsphere.no)>Number(this.tempcylinder.no))
      {
        this.lefteyeresultofspherecylinder=this.tempsphere;
      }else{
        this.lefteyeresultofspherecylinder=this.tempcylinder;
      }
      
  }
  else{
    this.lefteyeresultofspherecylinder=this.resultcompare.find(obj=>{
      return obj.color==this.leftcylinder.color
    });
  }

    // Right EYE Power Result

    if(Number(this.rightpower.no)<=1)
    {
      this.righteyepowerresult={value:'Beginners Progressive',no:0};
    }else{
      this.righteyepowerresult={value:'Progressive Lense Design',no:1};
    }
    // Left EYE Power Result

    if(Number(this.leftpower.no)<=1)
    {
      this.lefteyepowerresult={value:'Beginners Progressive',no:0};
    }else{
      this.lefteyepowerresult={value:'Progressive Lense Design',no:1};
    }
    
    // Final Power Result
    if(Number(this.righteyepowerresult.no)>Number(this.lefteyepowerresult.no))
    {
      this.finalpower=this.righteyepowerresult;
    }else if(Number(this.righteyepowerresult.no) == Number(this.lefteyepowerresult.no))
    {
      this.finalpower=this.righteyepowerresult;
    }else{
      this.finalpower=this.lefteyepowerresult;
    }
 
    // Final Result
    if(Number(this.righteyeresultofspherecylinder.no)>Number(this.lefteyeresultofspherecylinder.no))
    {
        this.finalresult=this.righteyeresultofspherecylinder;
    }else{
      this.finalresult=this.lefteyeresultofspherecylinder;
    }

    //Light Sensitivity;
    let result
    if(this.light==true)
    {
       result='Blue Light Filter and Transition'
    }else
    {
      result='Blue Light Filter';
    }
    var rightconcat=this.rightprism.no+" "+this.rightprismdirection.no;
    var leftconcat=this.leftprism.no+" "+this.leftprismdirection.no;
    this.ds.setclient({clientid:localStorage.getItem('id'),name:this.pname,doctor:this.dname,mail:this.mail,date:this.date.toLocaleDateString(),righteyesphere:this.rightsphere.no,righteyecylinder:this.rightcylinder.no,righteyeaxis:this.rightaxis.no,righteyeprism:rightconcat,righteyepower:this.rightpower.no,lefteyesphere:this.leftsphere.no,lefteyecylinder:this.leftcylinder.no,lefteyeaxis:this.leftaxis.no,lefteyeprism:leftconcat,lefteyepower:this.leftpower.no,righteyeresult:this.righteyeresultofspherecylinder.value,lefteyeresult:this.lefteyeresultofspherecylinder.value,finalresult:this.finalresult.value,finalpower:this.finalpower.value,lefteyepowerresult:this.lefteyepowerresult.value,righteyepowerresult:this.righteyepowerresult.value,age:this.agechk.no,glassesyouwear:this.glasseschk,screentime:this.screenchk.no,computeruse:this.computerchk.no,presentlywearglasses:this.glass,presentlywearcontact:this.lens,lightsensitivity:this.light,finalresultforcomputerandscreentime:'Blue Light Filter',resultforlightsensitivity:result,ad:this.value10}).subscribe((response)=>{
        if(response.status=="ok")
        {
            alert(this.finalresult.value+"\n"+this.finalpower.value);
            alert("Your Result is Send to your Mail Id")
            this.pname="";
            this.dname="";
            this.date;
            this.mail="";
            this.rightsphere=this.rightprismdirection=this.rightprism=this.rightpower=this.righteyeresultofspherecylinder=this.righteyepowerresult=this.rightcylinder=this.rightaxis="";
            this.leftaxis=this.leftcylinder=this.lefteyepowerresult=this.lefteyeresultofspherecylinder=this.leftpower=this.leftprism=this.leftprismdirection=this.leftsphere="";
            this.finalpower=this.finalresult="";
            this.agechk=this.glasseschk=this.screenchk=this.checked=this.computerchk="";
            this.checked=this.light=this.lens=this.glass=false;
            var tds=document.getElementsByTagName('td');
            for(var i = 0; i < tds.length; i++) {
              tds[i].style.background="transparent";
           }
        }else
        {
            alert("Sorry Your Result Is Not Submit Please Try Again");
        }
    })
  }
}
