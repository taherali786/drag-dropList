import { Component, OnInit } from '@angular/core';
import { DataService } from '../../data.service';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {
  event;
  bookedGlass;
  constructor(private ds:DataService) { }

  ngOnInit(): void {
      this.ds.getclient({id:localStorage.getItem('id')}).subscribe((response)=>{
        if(response.status=="ok")
        { 
          this.event=response.data;
        }else{
          alert(response.data);
        }
      })

      this.ds.getBookGlassDetail({id:localStorage.getItem('id')}).subscribe((response)=>{
        if(response.status=="ok"){
            this.bookedGlass=response.data;
        }else{

        }
      })


  }

}
