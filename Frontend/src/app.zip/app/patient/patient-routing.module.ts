import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppointmentComponent } from './appointment/appointment.component';
import { AuthconsultancyGuard } from './authconsultancy.guard';
import { ConsultancyComponent } from './consultancy/consultancy.component';
import { ContentlinkComponent } from './contentlink/contentlink.component';
import { EyecontactComponent } from './eyecontact/eyecontact.component';
import { HistoryComponent } from './history/history.component';

import { PatientComponent } from './patient.component';
import { PaymentComponent } from './payment/payment.component';
import { PricingComponent } from './pricing/pricing.component';
import { TryglassComponent } from './tryglass/tryglass.component';
import { UauthGuard } from './uauth.guard';
import { ViewComponent } from './view/view.component';

const routes: Routes = [
  { path: 'navbar-module', loadChildren: () => import('../navbar/navbar.module').then(m => m.NavbarModule) },
{path:'',component:PatientComponent,canActivate:[UauthGuard],children:[
  {path:'',component:ContentlinkComponent},
  {path:'eyeform',component:EyecontactComponent},
  {path:'view',component:ViewComponent},
  {path:'app',component:AppointmentComponent},
  {path:'try',component:TryglassComponent},
  {path:'consultancy',canActivate:[AuthconsultancyGuard],component:ConsultancyComponent},
  {path:'payment',component:PaymentComponent},
  { path: 'edit', loadChildren: () => import('../edit/edit.module').then(m => m.EditModule) },
  {path:'history',component:HistoryComponent},
  {path:'plan',component:PricingComponent}
  
]},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PatientRoutingModule { }
