import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PatientRoutingModule } from './patient-routing.module';
import { PatientComponent } from './patient.component';
import {HttpClientModule} from '@angular/common/http';
import { EyecontactComponent } from './eyecontact/eyecontact.component';
import { ContentlinkComponent } from './contentlink/contentlink.component';
import { ContentComponent } from './content/content.component';
import { ViewComponent } from './view/view.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { TryglassComponent } from './tryglass/tryglass.component';
import { HistoryComponent } from './history/history.component';
import { ConsultancyComponent } from './consultancy/consultancy.component';
import { FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
import interactionPlugin from '@fullcalendar/interaction';


// PrimeNg Modules
import {ToolbarModule} from 'primeng/toolbar';
import {InputNumberModule} from 'primeng/inputnumber';
import {MultiSelectModule} from 'primeng/multiselect';
import {FieldsetModule} from 'primeng/fieldset';
import {BasePanelMenuItem, PanelMenuModule} from 'primeng/panelmenu';
import {TabViewModule} from 'primeng/tabview';
import {PanelModule} from 'primeng/panel';
import {ColorPickerModule} from 'primeng/colorpicker';
import {SidebarModule} from 'primeng/sidebar';
import {PasswordModule} from 'primeng/password';
import {DataViewModule} from 'primeng/dataview';
import {FileUploadModule} from 'primeng/fileupload';
import {SelectButtonModule} from 'primeng/selectbutton';
import {DropdownModule} from 'primeng/dropdown';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {InputSwitchModule} from 'primeng/inputswitch';
import {CheckboxModule} from 'primeng/checkbox';
import {ButtonModule} from 'primeng/button';
import {InputTextModule} from 'primeng/inputtext';
import {CalendarModule} from 'primeng/calendar';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {TableModule} from 'primeng/table';
import { NavbarModule } from '../navbar/navbar.module';
import { PaymentComponent } from './payment/payment.component';

FullCalendarModule.registerPlugins([ // register FullCalendar plugins
  dayGridPlugin,
  timeGridPlugin,
  listPlugin,
  interactionPlugin
]);


@NgModule({
  declarations: [PatientComponent,
        EyecontactComponent,
        ContentlinkComponent,
        ContentComponent,
        ViewComponent,
        AppointmentComponent,
        ViewComponent,
        TryglassComponent,
        HistoryComponent,
        ConsultancyComponent,
        PaymentComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    PatientRoutingModule,
    // BrowserModule,
    InputTextModule,
    CalendarModule,
    
    ReactiveFormsModule,
    DropdownModule,
    InputTextareaModule,
    PasswordModule,
    DataViewModule,
    FileUploadModule,
    ColorPickerModule,
    ToolbarModule,
    TabViewModule,
    PanelModule,
    SelectButtonModule,
    FieldsetModule,
    InputSwitchModule,
    CheckboxModule,
    HttpClientModule,
    ButtonModule,
    TableModule,
    InputNumberModule,
    SidebarModule,
    PanelMenuModule,
    MultiSelectModule,
    FullCalendarModule,
    NavbarModule
  ]
})
export class PatientModule { }
