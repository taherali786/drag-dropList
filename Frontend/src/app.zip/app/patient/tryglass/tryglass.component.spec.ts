import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TryglassComponent } from './tryglass.component';

describe('TryglassComponent', () => {
  let component: TryglassComponent;
  let fixture: ComponentFixture<TryglassComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TryglassComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TryglassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
