import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { environment } from '../../environments/environment';
import $ from "jquery";


import {loadStripe} from '@stripe/stripe-js';
import { DataService } from '../data.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  Amount;
  Name;
  Phone;
  stripe;
  card;
  loading:boolean;
  disable:boolean;
  id;
  btn='Confirm Payment';
  AmountArr=[
    {id:'qrtyecter197220@34!*&%%#(',amount:10},
    {id:'qazccter17427420@34!*&%~!@',amount:20},
    {id:'qaancyreter12036920@34!*&%=-&^',amount:30},

  ]
  constructor(
   private route:ActivatedRoute,
    private ds:DataService,
    private router:Router
  ) { }

  async ngOnInit() {

    this.stripe = await loadStripe(environment.STRIPE_PUBLIC_KEY);
    
    this.MountWidget();

    this.route.queryParamMap.subscribe((e)=>{
      if(e.get('id'))
      {
        this.id=e.get('id')
        let amount=this.AmountArr.find(x=>x.id==this.id)
        this.Amount=amount.amount
      }
    })

    
  }

  
  buy(){
    var err=document.getElementById('card-errors');
    var submitBtn=document.getElementById('submit');
    let d=new Date();
    d.setMinutes(d.getMinutes()-2)
    if(Boolean(this.Name) && Boolean(this.Amount) && Boolean(this.Phone)){
     
    setTimeout(() => {
      
      this.loading=true;
      this.btn='Pending..';
     
      //Verify Card
      this.stripe.createToken(this.card).then((result)=>{
        if(result.error){
         
          err.textContent=result.error.message;
          this.loading=false;
          this.btn='Payment Failed';
          submitBtn.classList.add('btn-danger');
          return true;
        }
          this.ds.Payment({name:this.Name,phone:this.Phone,
            Tokenid:result.token.id,CardId:result.token.card.id,CardLastFourDigit:result.token.card.last4,CardType:result.token.card.object,cardBrand:result.token.card.brand
            ,clientIp:result.token.client_ip,desc:'Online Consultancy',PatientId:localStorage.getItem('id'),
            PatientName:localStorage.getItem('name'),PatientEmail:localStorage.getItem('email'),PaymentStatus:true
          ,AmtId:this.id}).subscribe(async (response)=>{
                    if(response.status==true){
                          console.log(response.data)
                          this.loading=false;
                          this.btn='Payment Succesfull';
                         
                          submitBtn.classList.remove('btn-primary');
                          submitBtn.classList.remove('btn-danger');
                          submitBtn.classList.add('btn-success');
                          setTimeout(() => {
                            this.router.navigate(['/Pdashboard/consultancy']);
                          }, 1000);
                    }else{
                      console.log(response.data)
                      this.loading=false;
                      this.btn='Payment Failed';
                    }
          })
      }
      ).catch((error)=>{
          err.textContent=error;
      })
    
    },1000);
    }else{
      err.textContent='Please Fill All Fields';
    }
  }

  // Stripe Mount WIdget

  MountWidget(){
    const elements=this.stripe.elements({
      // Stripe's examples are localized to specific languages, but if
      // you wish to have Elements automatically detect your user's locale,
      // use `locale: 'auto'` instead.
      locale: 'auto'
    });

    let style= {
          base: {
            iconColor: '#666EE8',
            color: '#31325F',
            lineHeight: '20px',
            fontWeight: 300,
            fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
            fontSize: '16px',
            '::placeholder': {
              color: '#555'
            }
          },
          inavlid:{
            color:'#fa755a',
            iconColor:'#fa755a'
          }
        }

    this.card=elements.create('card',{ iconStyle: "solid",style:style,hidePostalCode:true})

    this.card.mount('#card-element')
  
  }



}
