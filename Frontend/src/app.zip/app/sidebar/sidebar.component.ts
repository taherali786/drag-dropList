import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { DataService } from '../data.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  display = false;
  items: MenuItem[];
  name = localStorage.getItem('name');
  imgshow=false;
  imghide=true;
  location = localStorage.getItem('location');
  imagePath = localStorage.getItem('image');
  imagepath = 'http://localhost:3000/';
  //imagepath = 'http://18.223.136.68:7000/';
  data;
  image;
  imgProp;
  constructor(private ds:DataService) {
    if(localStorage.getItem('image')!='undefined'){
     this.image=this.imagepath+localStorage.getItem('image')
    }else{
      this.image="../assets/images/icon.png";
    }
  }

  ngOnInit(): void {

    this.items = [
      {
        label: 'Upcoming Appointment',
        icon: 'pi pi-fw pi-calendar-plus',
        routerLink: '/Ddashboard'
      },
      {
        label: 'Todays Appointment',
        icon: 'pi pi-fw pi-calendar',
        routerLink: 'todayevent'
      },
      {
        label: 'Past Appointment',
        icon: 'pi pi-fw pi-calendar-minus',
        routerLink: 'pastevent'
      },
      {
        label: 'Patient Detail',
        icon: 'pi pi-fw pi-user',
        routerLink: 'patientdetail'
      },
      {
        label: 'Appointment Setting',
        icon: 'pi pi-fw pi-cog',
        routerLink: 'set'
      }
    ]


  }

  async selectimage(ev){
    const formdata =new FormData();
    if(ev.target.files.length>0){
      const file=ev.target.files[0];
      this.data=await file;  
    }
    
    formdata.append('imgfile',this.data);
    formdata.append('id',localStorage.getItem('id'))
    this.ds.UpdateUserPic(formdata).subscribe((response)=>{
      if(response.status=="ok"){
          this.imagePath=response.data[0].image;
          localStorage.setItem('image',this.imagePath);
          this.image=this.imagepath+localStorage.getItem('image')

      }else{
        console.log(response.data)
      }
    })
  }

}
