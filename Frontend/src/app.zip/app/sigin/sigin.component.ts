import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';
import { DataService } from '../data.service';

@Component({
  selector: 'app-sigin',
  templateUrl: './sigin.component.html',
  styleUrls: ['./sigin.component.css']
})
export class SiginComponent implements OnInit {
emailProp;
passwordProp;
secretkey:string='ch@kkiwala199953';
  constructor(private ds:DataService,private router:Router) { }

  ngOnInit(): void {
  }

  signin()
  {
    if(Boolean(this.passwordProp) && Boolean(this.emailProp)){

      var hash=CryptoJS.SHA256(this.passwordProp);
      var password=hash.toString(CryptoJS.enc.Hex);
      this.ds.signin({email:this.emailProp,password:password})
      .subscribe((response)=>{
        if(response.status=="ok"){
  
        if(response.data[0].role=="Doctor"){
         if(response.data[0].request=='Pending'){
           alert('Your ID is not Accepted By Admin Yet Please Wait For Some Time');
           return true;
         }
         else if(response.data[0].request=='Block'){
          alert('Your ID is Blocked By Admin');
          return true;
         }
         else if(response.data[0].request=='Accept'){
          localStorage.setItem("id",response.data[0]._id);
          localStorage.setItem("name",response.data[0].name);
          localStorage.setItem("email",response.data[0].email);
          localStorage.setItem("role",response.data[0].role);
          localStorage.setItem("location",response.data[0].location);
          localStorage.setItem('speciality',response.data[0].speciality);
          localStorage.setItem('fee',response.data[0].fee);
          localStorage.setItem('image',response.data[0].image)
          alert("you are login");
          this.router.navigate(['/doctor']);
         }
         
        }else{
          console.table(response.data)
          localStorage.setItem("id",response.data[0]._id);
          localStorage.setItem("name",response.data[0].name);
          localStorage.setItem("email",response.data[0].email);
          localStorage.setItem("role",response.data[0].role);
          localStorage.setItem('location',response.data[0].location);
          localStorage.setItem('image',response.data[0].image)
          alert("you are login");
          this.router.navigate(['/patient-module']);
        }
        
    
        }else{
          alert(response.data);
        }
      })
      
    }
   
  }

}
