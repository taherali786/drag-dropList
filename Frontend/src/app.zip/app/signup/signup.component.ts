import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../environments/environment';

import {loadStripe} from '@stripe/stripe-js';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  stateOptions: any[];
  value1;
  nameProp;
  emailProp;
  passwordProp;
  confpasswordProp;
  roleProp;
  ifrole=false;
  locationProp;
  specialityProp;
  descriptionProp;
  feeProp;
  secretkey:string='ch@kkiwala199953';


  // Stripe element
  stripe;
  card;
  
  name=false;pass=false;email=false;location=false;confpass=false;speciality=false;fee=false;roleErr=false;err=false;
  constructor(private router:Router,private ds:DataService) { 
    this.stateOptions = [{label: 'Doctor', value: 'Doctor'}, {label: 'Patient', value: 'Patient'}];
  }

  async ngOnInit(){
    this.stripe = await loadStripe(environment.STRIPE_PUBLIC_KEY);
    
    this.MountWidget();
  }
  role(){
    if(this.roleProp=='Doctor'){
      this.ifrole=true;
     }else{
       this.ifrole=false;
     }
  }
  signup()
  {  
    if(Boolean(this.nameProp)==false){
      this.name=true;
      return true;
    }else
      this.name=false;
    
    if(Boolean(this.emailProp)==false){
      this.email=true;
      return true;
    }else
    this.email=false;
    if(Boolean(this.passwordProp)==false){
      this.pass=true;
      return true;
    }else
    this.pass=false;
    if(Boolean(this.confpasswordProp)==false){
      this.confpass=true;
      return true;
    }else
    this.confpass=false;
    if(Boolean(this.roleProp)==false){
      this.roleErr=true;
      return true;
    }else
    this.roleErr=false;
    if(Boolean(this.locationProp)==false){
      this.location=true;
      return true;
    }else
    this.location=false;
    if(Boolean(this.nameProp) && Boolean(this.emailProp) && Boolean(this.passwordProp) && Boolean(this.confpasswordProp) && Boolean(this.roleProp) && Boolean(this.locationProp))
    {
      var x=this.emailProp;  
    var atposition=x.indexOf("@");  
    var dotposition=x.lastIndexOf("."); 
    if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length){  
      document.getElementById('err').innerText='Please enter a valid e-mail address';
      //alert("Please enter a valid e-mail address");  
      return true;  
      }  
     if(this.passwordProp!=this.confpasswordProp){
       document.getElementById('err').innerText='Both Password Are Not Matched';
       // alert('Both Password Are NotMatched');
       return true;
     }
     if(this.roleProp=='Doctor'){
       if(Boolean(this.specialityProp)==false){
         this.speciality=true;
        //alert('Please Enter Specialization');
        return true;
       }else
        this.speciality=false;
       if(Boolean(this.feeProp)==false){
         this.fee=true;
       // alert('Please Enter Appointment Fee');
        return true;
       }else
       this.fee=false;
       var hash=CryptoJS.SHA256(this.passwordProp);
      var password=hash.toString(CryptoJS.enc.Hex);
      this.ds.signup({name:this.nameProp,email:this.emailProp,password:password,role:this.roleProp,location:this.locationProp,speciality:this.specialityProp,fee:this.feeProp,desc:this.descriptionProp,request:'Pending'})
      .subscribe(async (response)=>{
        if(response.status=="ok")
        {
         //alert("you are successfully registered");
         
          this.nameProp='';
          this.emailProp='';
          this.passwordProp='';
          this.confpasswordProp='';
          this.roleProp='';
          this.locationProp='';
          this.specialityProp='';
          this.feeProp='';
          document.getElementById('click2').click();
        }else{
          document.getElementById('err').innerText=response.data;
          //alert(" You Are Not Registered");
        }
      })
     }else{
      var hash=CryptoJS.SHA256(this.passwordProp);
      var password=hash.toString(CryptoJS.enc.Hex);
      
      this.ds.signup({name:this.nameProp,email:this.emailProp,password:password,role:this.roleProp,location:this.locationProp,request:'Pending'})
      .subscribe((response)=>{
        if(response.status=="ok")
        {
         alert("you are successfully registered");
   
           this.router.navigate(['/']);
        }else{
          document.getElementById('err').innerText=response.data;
          //alert(" You Are Not Registered");
        }
      })
     }
    }else{

     // alert("Please Fill All Fields");
      return true;
    }
   
  }

  // Start Mount Card

  MountWidget(){
    const elements=this.stripe.elements({
      // Stripe's examples are localized to specific languages, but if
      // you wish to have Elements automatically detect your user's locale,
      // use `locale: 'auto'` instead.
      locale: 'auto'
    });

    let style= {
          base: {
            iconColor: '#666EE8',
            color: '#31325F',
            lineHeight: '20px',
            fontWeight: 300,
            fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
            fontSize: '16px',
            '::placeholder': {
              color: '#555'
            }
          },
          inavlid:{
            color:'#fa755a',
            iconColor:'#fa755a'
          }
        }

    this.card=elements.create('card',{ iconStyle: "solid",style:style,hidePostalCode:true})

    this.card.mount('#card-element')
  
  }

  // End Mount Card

}
