import { BOOL_TYPE } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { dragStart } from '@syncfusion/ej2-angular-schedule';
import { DataService } from '../data.service';

@Component({
  selector: 'app-tryglass',
  templateUrl: './tryglass.component.html',
  styleUrls: ['./tryglass.component.css']
})
export class TryglassComponent implements OnInit {
  nameProp;
  mailProp;
  phoneProp;
  modelProp;
  locationProp;
  model=false;
  phone=false;
  mail=false;
  name=false;
  location=false;
  color;
  constructor(private ds:DataService) { }

  ngOnInit(): void {
  }

  BookGlass(){
    document.getElementById('click').click();
  }

  submit(){
    if(Boolean(this.nameProp)==false){
      this.name=true;
      return true;
    }else{
      this.name=false;
    }
    if(Boolean(this.mailProp)==false){
      this.mail=true;
      return true;
    }else{
      this.mail=false;
    }
    if(Boolean(this.phoneProp)==false){
      this.phone=true;
      return true;
    }else{
      this.phone=false;
    }
    if(Boolean(this.modelProp)==false){
      this.model=true;
      return true;
    }else{
      this.model=false;
    }
    if(Boolean(this.locationProp)==false){
      this.location=true;
      return true;
    }else{
      this.location=false;
    }

    this.ds.bookGlass({id:localStorage.getItem('id'),name:this.nameProp,phone:this.phoneProp,mail:this.mailProp,model:this.modelProp,location:this.locationProp}).subscribe((response)=>{
        this.nameProp=this.mailProp=this.locationProp=this.phoneProp=this.modelProp='';
        document.getElementById('close').click();
        document.getElementById('click2').click()
    },(err)=>{
        console.log(err)
    })
    
  }

  selectimage(e){}

}
