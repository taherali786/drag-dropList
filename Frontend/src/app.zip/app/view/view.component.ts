import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { LazyLoadEvent, PrimeNGConfig } from 'primeng/api';
import { DataService } from '../data.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss'],
  styles: [`
        .loading-text {
            display: block;
            background-color: #f1f1f1;
            min-height: 19px;
            animation: pulse 1s infinite ease-in-out;
            text-indent: -99999px;
            overflow: hidden;
        }
    `]
})
export class ViewComponent implements OnInit {

  cars=[
    {name:'Dr. X',description:'Eye Specialist',category:'Canada',inventoryStatus:'Instock',price:85,image:"../assets/images/logo.png"},
    {name:'Dr. Y',description:'Eye Specialist',category:'London',inventoryStatus:'Out Of Stock',price:75,image:"../assets/images/logo.png"},
    {name:'Dr. Z',description:'Eye Specialist',category:'India',inventoryStatus:'Instock',price:65,image:"../assets/images/logo.png"}
   ];
   sortOptions: any[];
   
       sortKey: string;
   
       sortField: string;
   
       sortOrder: number;
       product=[];
       doctorlist;
       image="../assets/images/logo.png";
       totalRecords: number;
       laziness:boolean=true;
       loading:boolean;
       imagePath="../assets/images/icon.png";
       //imagePath = localStorage.getItem('image');
        imagepath = 'http://localhost:3000/';
         //imagepath = 'http://18.223.136.68:7000/';
        time:Date;
        datesearch:Date;
        first;
        row;
        tempdate;
     constructor(private ds:DataService,private primengConfig: PrimeNGConfig,private router:Router) { }
   
     ngOnInit(): void {
       this.sortOptions = [
         {label: 'Low Price', value: '!year'},
         {label: 'High Price', value: 'year'}
     ];
     this.primengConfig.ripple = true;

        this.ds.getdoctorinfo({}).subscribe(async (response)=>{
              if(response.status=="ok")
              {
                  this.doctorlist=await response.data.doctorlist;
                  this.totalRecords=await response.data.doctorcount;
                  this.loading=true;
              }
              else{
                  alert(response.data);
              }
        })
     }
     onSortChange(event) {
       let value = event.value;
   
       if (value.indexOf('!') === 0) {
           this.sortOrder = -1;
           this.sortField = value.substring(1, value.length);
       }
       else {
           this.sortOrder = 1;
           this.sortField = value;
       }
     }

     appoint(ev){
      // alert(ev);
      this.router.navigate(['/Pdashboard/app'],{queryParams:{id:ev}});

     }

     loadCustomers(event:LazyLoadEvent){
      setTimeout(() => {
        this.loading=true;
        if (this.doctorlist) {
          //alert('hello')
          this.first=event.first;
          this.row=event.rows;
          this.ds.getdoctorinfo({skip:event.first,limit:event.rows,date:this.tempdate}).subscribe(async (response) => {
            if (response.status == "ok") {
              this.doctorlist=await response.data.doctorlist;
              this.totalRecords=await response.data.doctorcount;
              this.loading=false;
            }
            else
              alert(response.message)
              this.loading=false;
          })
        }
      }, 1000);
    }


    datePicker(){
      let temp=new Date(this.datesearch.toISOString().split('T')[0]);
      temp.setDate(temp.getDate()+1)
      this.tempdate=temp.toISOString().split('T')[0]
     
      setTimeout(() => {
        this.loading=true;
        if (this.doctorlist) {
          //alert('hello')
          this.ds.getdoctorinfo({skip:this.first,limit:this.row,date:this.tempdate}).subscribe(async (response) => {
            if (response.status == "ok") {
              this.doctorlist=await response.data.doctorlist;
              this.totalRecords=await response.data.doctorcount;
              this.loading=false;
            }
            else
              alert(response.message)
              this.loading=false;
          })
        }
      }, 1000);
    }

    TimePicker(){
      this.time.setUTCSeconds(0);
     let checktime= this.time.toLocaleTimeString('en-GB',{hour: '2-digit', minute:'2-digit'});

     setTimeout(() => {
      this.loading=true;
      if (this.doctorlist) {
        //alert('hello')
        this.ds.getdoctorinfo({skip:this.first,limit:this.row,date:this.tempdate,time:checktime}).subscribe(async (response) => {
          if (response.status == "ok") {
            this.doctorlist=await response.data.doctorlist;
            this.totalRecords=await response.data.doctorcount;
            this.loading=false;
          }
          else
            alert(response.message)
            this.loading=false;
        })
      }
    }, 1000);
      
    }
}
